// px2rem设置
/*
 * 750px(iphone6)宽度为基准
 * */
const viewportWidth = 1920;
const viewportHeight = 1080;
const unitPrecision = 5;
const viewportUnit = 'vw';

module.exports = {
  plugins: {
    'postcss-flexbugs-fixes': {},
    autoprefixer: {
      browsers: [
        '>1%',
        'last 4 versions',
        'Firefox ESR',
        'not ie < 9', // React doesn't support IE8 anyway
      ],
      flexbox: 'no-2009',
    },
    'postcss-aspect-ratio-mini': {},
    'postcss-write-svg': { utf8: false },
    'postcss-cssnext': {},
    'postcss-px-to-viewport': {
      viewportWidth,
      viewportHeight,
      unitPrecision,
      viewportUnit,
      selectorBlackList: ['.ignore', '.hairlines'],
      minPixelValue: 1,
      mediaQuery: false,
    },
    'postcss-viewport-units': {},
    cssnano: {
      'cssnano-preset-advanced': {
        zindex: false,
        autoprefixer: false,
      },
    },
  },
};
