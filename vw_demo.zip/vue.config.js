
const pagesEntry = ['index', 'front'];
const pagesTitle = {
  index: '智慧楼宇-主屏',
  front: '智慧楼宇-前台',
};

const pages = {};
pagesEntry.forEach((item) => {
  pages[item] = {
    entry: `src/entry/main-${item}.js`,
    template: 'public/index.html',
    filename: `${item}.html`,
    title: pagesTitle[item],
    chunks: ['chunk-vendors', 'chunk-common', item],
  };
});

module.exports = {
  // publicPath: process.env.NODE_ENV === 'production'
  //     ? '/production-sub-path/'
  //     : '/',
  lintOnSave: 'error',
  devServer: {
    overlay: {
      // warnings: true,
      errors: true,
    },
  },
  pages,
};
