# 生物岛大屏

## 基本介绍

* 安装 `yarn`
* 运行 `yarn serve`
* 打包 `yarn build`
* 代码检测 `yarn lint`