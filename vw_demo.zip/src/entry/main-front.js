import Vue from 'vue';
import App from '@/App.vue';
import '@/assets/styles/reset.css';
import '@/assets/styles/common.less';
import router from '@/routers/front';
import axiosInstance from '@/plugins/axios/index';

Vue.config.productionTip = false;
Vue.prototype.$axios = axiosInstance;

new Vue({
  router,
  render: h => h(App),
}).$mount('#app');
