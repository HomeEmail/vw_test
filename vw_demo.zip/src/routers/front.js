import Vue from 'vue';
import Router from 'vue-router';
import defaultComponent from '@/views/front/default.vue';

Vue.use(Router);

export default new Router({
  // mode: 'history',
//   base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      component: defaultComponent,
    },
    {
      path: '/subPage',
      name: 'subPage',
      component: () => import('@/views/front/subPage.vue'),
    },
  ],
});
