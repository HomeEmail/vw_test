import Vue from 'vue';
import Router from 'vue-router';
import defaultComponent from '@/views/index/default.vue';

Vue.use(Router);

export default new Router({
  // mode: 'history',
//   base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      component: defaultComponent,
    },
    {
      path: '/subPage',
      name: 'subPage',
      component: () => import('@/views/index/subPage.vue'),
    },
    {
      path: '/vuexDemo',
      name: 'vuexDemo',
      component: () => import('@/views/index/vuexDemo.vue'),
    },
    {
      path: '/axiosDemo',
      name: 'axiosDemo',
      component: () => import('@/views/index/axiosDemo.vue'),
    },
  ],
});
