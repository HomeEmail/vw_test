export default {
  valPlus: (state) => {
    const { val } = state;
    return val + 1;
  },
};
