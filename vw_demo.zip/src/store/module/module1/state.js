export default {
  val: 0,
};
