export default {
  // 获取val
  getVal({ commit }) {
    commit('GET_VAL');
  },

};
