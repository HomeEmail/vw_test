<template>
    <h1>{{lighting}}</h1>
</template>

<script>
export default {
  name: 'default',
  data() {
    return {
      lighting: '123',
    };
  },
};
</script>
