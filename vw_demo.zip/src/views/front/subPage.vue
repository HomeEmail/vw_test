<template>
    <h1>front-subpage</h1>
</template>
