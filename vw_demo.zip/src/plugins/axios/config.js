export default {
  timeout: 10000,
  baseURL: process.env.VUE_APP_BASE_URL,
};
